TIZEN ULTRA PLAYER — ALL GENERATIONS SOURCE

Folders:
- 2015_2018: older Tizen target configuration
- 2019_2021: middle Tizen target configuration
- 2022_2026: newer Tizen target configuration

Each folder contains config.xml, index.html, icon.png, and README.txt.
The HTML/JavaScript app is the same across variants; the package identity and required Tizen version differ.

Important: year ranges are only rough targeting. Exact compatibility depends on the TV's model code and firmware. All .wgt files are unsigned and must normally be signed with valid certificates in Samsung TV Extension/Tizen Studio before installation. The app does not bypass DRM or provider restrictions.
