TIZEN ULTRA PLAYER — 2022–2026 target

This is a compatibility-targeted WGT archive. The target version is a build setting, not a guarantee that every TV in this year range can install or run it.

Features: direct URL playback attempts, M3U text parsing and URL fetch, favorites, recent history, local file picker attempt, download-link attempt.

Limitations:
- Package is unsigned; use Samsung TV Extension/Tizen Studio and your certificates to sign it.
- TV model, firmware and Tizen version determine installation and API support.
- Direct media URLs are more likely to work than hosted webpage URLs. VidLink-style pages may block embedding or require DRM/authentication.
- A Tizen web app cannot freely scan all USB folders or guarantee saving videos to USB.
- Remote M3U fetch can fail when the server blocks cross-origin requests (CORS).
